#ifndef HEADER_NetworkIOMeter
#define HEADER_NetworkIOMeter

#include "Meter.h"

extern const MeterClass NetworkIOMeter_class;

#endif /* HEADER_NetworkIOMeter */
