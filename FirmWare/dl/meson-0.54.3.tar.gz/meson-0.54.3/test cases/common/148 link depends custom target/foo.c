#include <stdio.h>

int main(void) {
  const char *fn = DEPFILE;
  FILE *f = fopen(fn, "r");
  if (!f) {
    printf("could not open %s", fn);
    return 1;
  }
  else {
    printf("successfully opened %s", fn);
  }

  return 0;
}
