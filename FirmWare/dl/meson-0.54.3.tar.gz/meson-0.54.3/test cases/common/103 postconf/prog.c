#include"generated.h"

int main(void) {
    return THE_NUMBER != 9;
}
