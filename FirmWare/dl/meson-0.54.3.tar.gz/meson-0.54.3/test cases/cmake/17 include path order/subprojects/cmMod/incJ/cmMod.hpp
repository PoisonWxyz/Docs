// cmMod.hpp (J)
#pragma once

#error "cmMod.hpp in incJ must not be included"
