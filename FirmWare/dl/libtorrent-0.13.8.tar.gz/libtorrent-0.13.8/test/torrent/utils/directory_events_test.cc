#include "config.h"

#include <tr1/functional>
#include <torrent/exceptions.h>
#include <torrent/utils/directory_events.h>

#include "directory_events_test.h"

CPPUNIT_TEST_SUITE_REGISTRATION(utils_directory_events_test);

namespace tr1 { using namespace std::tr1; }

void
utils_directory_events_test::setUp() {
}

void
utils_directory_events_test::tearDown() {
}

void
utils_directory_events_test::test_basic() {
}
