/* winconfig.h.  Win32 replacement for file generated from config.h.in by configure.  */

/* OS name */
#define PACKAGE_OSNAME N2N_OSNAME

/* Define to the version of this package. */
#define PACKAGE_VERSION N2N_VERSION
#define GIT_RELEASE N2N_VERSION
